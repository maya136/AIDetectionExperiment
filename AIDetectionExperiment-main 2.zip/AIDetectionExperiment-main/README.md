This is a repository for Experimental Psychology Course paper by Maya Ely and Gali.
